
streaming_subreddits = [
{'name': 'Adams Links', 'url': 'AdamsSparkle'},
{'name': 'Soccer Streams', 'url': 'footballconnection'},
{'name': 'MMA Streams', 'url': 'MMAStreams'},
{'name': 'Tennis Streams', 'url': 'TennisStreams'},
{'name': 'Boxing Streams', 'url': 'BoxingStreams'},
{'name': 'Rugby Streams', 'url': 'RugbyStreams'},
{'name': 'Motor Sports Streams', 'url': 'motorsportsstreams'},
{'name': 'WWE Streams', 'url': 'WWEstreams'}
]
